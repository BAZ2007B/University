﻿//Базаров Алмазбек Султанбаевич
// КИ20-07б(1 подгруппа)
//сложность : 100%
//2 вариант
/*
Определить есть ли в списке узел, содержащий совершенное число. Если такое число есть, то после него вставить три узла, содержащих
случайные натуральные числа, не меньше этого числа
*/

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <clocale>
#include <cstdlib>
using namespace std;

struct node { // динамический односвязный список
    int num; // число
    node* next; //узел
};

void CoutNode(node* start, node* tail) { // функция вывода списка
    for (node* cur = start; cur != NULL; cur = cur->next)
        cout << cur->num << " ";
}

bool FindPerfect(int a) { // функция нахождения совершенного числа
    bool x; // возвращаем логическое значение
    int sum = 0, c;
    for (int i = 1; i <= (a / 2); i++) {
        c = a % i;
        if (c == 0) sum = sum + i;
    }
    if (sum == a) x = 1; // если число совершенно, возвращаем правду
    else x = 0; // если число не совершенно, возвращаем ложь
    return x; // возвращаем логическое значени
}

void TabuTask(node* start, node* tail) { // функция добавления узлов после совершенного числа
    node* newnode; // создание вспомогательного числа
    while (tail != NULL) { // пока список не кончился
        bool b = FindPerfect(tail->num); // определение совершенного числа
        if (b == true) { // если число совершенно
            for (int i = 0; i < 3; i++) { // добавляем три узла после узла с совершенным числом
                newnode = new node;
                newnode->num = tail->num + rand();
                newnode->next = tail->next;
                tail->next = newnode;
            }
        }
        tail = tail->next; // переход к следующему узлу списка
    }
}

int main()
{
    setlocale(LC_ALL, "russian");
    ifstream in; // создание объекта для чтения текстового файла
    in.open("file.txt"); // открытие текстового файла
    node* start, * tail; // создание двух узлов для работы со списком
    start = NULL; // определяем начало списка
    while (!in.eof()) { // содаем список путем чтение из файла, пока файл не закончится
        tail = new node; // создаем новый узел
        tail->next = start; // как бы толкаем начало вниз
        in >> tail->num; // читаем из файла число
        start = tail; // определяем вершину списка
    }
    in.close(); // закрываем текстовый файл
    tail = start; //определяем новую вершину списка после окончания чтения
    cout << "Изначальный список" << endl;
    CoutNode(start, tail); // выводим список
    cout << endl;
    TabuTask(start, tail);// изменяем список по заданию
    cout << "Измененный список" << endl;
    CoutNode(start, tail);// выводим измененный список
    cout << endl;
    return 0;
}
