﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 4 Z2
//Определить, принадлежит ли действительное число x объединению отрезков [a; b], [c; d].

#include <clocale>
#include <iostream>
using namespace std;

int main()
{
    setlocale(LC_ALL, "russian");
    float a, b, c, d, x;
    cout << "Введите a и b через пробел(концовки отрезка [a,b](a < b) :)";
    cin >> a >> b;
    cout << "Введите c и d через пробел(концовки отрезка [c,d](c < d) :)";
    cin >> c >> d;
    cout << "Введите x :";
    cin >> x;
    if ((x >= a && x <= b) || (x >= c && x <= d))
        cout << "Принадлежит";
    else cout << "Не принадлежит";
    return 0;
}