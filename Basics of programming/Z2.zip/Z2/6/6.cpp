﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 6 Z2
/*Найти действительные корни квадратного уравнения ax^2+bx+c=0. Если корней нет, вывести сообщение. 
Вывести значения левой части уравнения после подстановки найденных корней.*/

#include <clocale>
#include <iostream>
#include <math.h>
using namespace std;

int main()
{
    setlocale(LC_ALL, "russian");
    int a, b, c;
    float D, x1, x2;
    cout << "Введите через пробел a , b и c :";
    cin >> a >> b >> c;
    D = pow(b, 2)-(4*a*c);
    if (D < 0) cout << "Корней нет";
    else if (D == 0) {
        x1 = (-b) / (2 * a); 
        cout << "Единственный корень = " << x1;
    } else {
        x1 = ((-b)+(sqrt(D)))/(2 * a);
        x2 = ((-b)-(sqrt(D)))/(2 * a);
        cout << "Корень x1 = " << x1 << "\nКорень x2 = " << x2;

    }
    return 0;
}

