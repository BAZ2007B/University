﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 23 (Z8)
/* Написать функцию int count_equal(int arr[], int len, int x), которая возвращает число элементов массива arr[] размера len, равных x.*/

#include <iostream>
#include <clocale>
using namespace std;

int* read_array(int len) {
    int* arr = new int[len];
    for (int i = 0; i < len; i++) cin >> *(arr+i);
    return arr;
}

int count_equal(int *arr, int len, int x) {
    int sum = 0;
    for (int i = 0; i < len; i++) if (*(arr+i) == x) sum = sum + 1;
    return sum;
}

int main() {
    setlocale(LC_ALL, "russian");
    int a, x, sum;
    int* b;
    cout << "Введите размер массива:";
    cin >> a;
    b = read_array(a);
    cout << "Введите x:";
    cin >> x;
    sum = count_equal(b, a, x);
    cout << "Кол-во элементов массива, равных x, равно " << sum;
    return 0;
}