﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 22 (Z8)
/* Написать функцию void print_array(int arr[], int len), которая выводит на экран первые len элементов массива arr*/

#include <iostream>
#include <clocale>
using namespace std;

int* read_array(int len) {
    int* arr = new int[len];
    for (int i = 0; i < len; i++)  cin >> *(arr+i);
    return arr;
}

void print_array(int *arr, int len) {
    for (int i = 0; i < len; i++) cout << *(arr+i) << " ";
    cout << endl;
}

int main() {
    setlocale(LC_ALL, "russian");
    int a, c;
    int* b;
    cout << "Введите размер массива:";
    cin >> a;
    b = read_array(a);
    print_array(b, a);
    cout << "Сколько первых элементов массива вы хотите вывести?";
    cin >> c;
    if (c > a) {
        while (c > a) {
            cout << "Кол-во элементов больше элементов массива, введите заново:";
            cin >> c;
        }
    }
    print_array(b, c);
    return 0;
}