﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 8 (Z3)
/*Определить расстояние d между двумя точками на числовой плоскости с координатами (x1, y1), (x2, y2). 
Вычисление расстояния оформить как функцию float dist(float x1, float y1, float x2, float y2).*/

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <clocale>
#include <stdio.h>
#include <conio.h>
#include <math.h> 

float dist(float x1, float y1, float x2, float y2) {
    float d,d1,d2;
    d1 = pow((x1 - x2), 2);
    d2 = pow((y1 - y2), 2);
    d = sqrt(d1 + d2);
    return d;
}

int main()
{
    float x, y, z, w, dend;
    setlocale(LC_ALL,"russian");
    printf("Введите x1 :");
    scanf("%f", &x);
    printf("Введите y1 :");
    scanf("%f", &y);
    printf("Введите x2 :");
    scanf("%f", &z);
    printf("Введите y2 :");
    scanf("%f", &w);
    dend = dist(x, y, z, w);
    printf("d = %.2f", dend);
    return 0;
}
