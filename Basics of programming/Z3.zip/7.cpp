﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 4 (Z3)
/*Даны числа a, b, c, d, которые могут быть равны 0 или 1. Определить, какое число встречается чаще. 
Алгоритм определения оформить как функцию int find_most_frequent(int a, int b, int c, int d). 
Функция должна возвращать: 0, если 0 встречается чаще; 1, если 1 встречается чаще; -1, если 0 и 1 встречаются одинаково часто.*/

#include <clocale>
#include <iostream>

using namespace std;

int find_most_frequent(int a, int b, int c, int d) {
    int sum = 0;
    sum = sum + a + b + c + d;
    if (sum > 2)
        cout << "1";
    else if (sum < 2)
        cout << "0";
    else cout << "-1";
    return 0;
}

int main()
{
    setlocale(LC_ALL, "russian");
    int x, y, z, w;
    cout << "Введите a:";
    cin >> x;
TryAgain1:
    if ((x != 1) && (x != 0)) {
        cout << "Введите a заново :";
        cin >> x;
        goto TryAgain1;
    }
    cout << "Введите b:";
    cin >> y;
TryAgain2:
    if ((y != 1) && (y != 0)) {
        cout << "Введите b заново :";
        cin >> y;
        goto TryAgain2;
    }
    cout << "Введите c:";
    cin >> z;
TryAgain3:
    if ((z != 1) && (z != 0)) {
        cout << "Введите c заново :";
        cin >> z;
        goto TryAgain3;
    }
    cout << "Введите d:";
    cin >> w;
TryAgain4:
    if ((w != 1) && (w != 0)) {
        cout << "Введите d заново :";
        cin >> w;
        goto TryAgain4;
    }
    find_most_frequent(x, y, z, w);
    return 0;
}
