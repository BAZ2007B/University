﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 9 (Z3)
/*Даны действительные числа a, b, c. Если a больше 0,5, вывести большее из чисел b, c. 
Иначе вывести меньшее из чисел b, c. Вычисление оформить как функцию float min_or_max(float a, float b, float c).*/

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <clocale>
#include <stdio.h>
#include <conio.h>
#include <math.h> 

float min_or_max(float a, float b, float c) {
    float a1 = 0.5;
    float max, min;
    if (a > a1) {
        max = b;
        if (c > b) max = c;
        printf("max = %.4f", max);
    }
    else {
        min = b;
        if (c < b) min = c;
        printf("min = %.4f", min);
    }
    return 0;
}

int main()
{
    setlocale(LC_ALL,"russian");
    float x, y, z;
    printf("Введите a :");
    scanf("%f",&x);
    printf("Введите b :");
    scanf("%f", &y);
    printf("Введите c :");
    scanf("%f", &z);
    min_or_max(x, y, z);
    printf("\nВСЕ");
    return 0;
}
