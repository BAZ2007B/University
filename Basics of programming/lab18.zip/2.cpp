﻿//Базаров Алмазбек Султанбаевич
// КИ20-07б(1 подгруппа)
//сложность : 100%
//2 вариант
/*
Определить есть ли в списке узел, содержащий совершенное число. Если такое число есть, то после него вставить три узла, содержащих
случайные натуральные числа, не меньше этого числа
*/

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <clocale>
#include <cstdlib>
using namespace std;

struct node { // динамический двусвязный список
	int num; // число
	node* next;// следующий узел
	node* prev;// предыдущий узел
};

void CoutNormal(node* head, node* tail) {
	for (node* cur = head; cur != NULL; cur = cur->next) {
		cout << cur->num << " ";
	}
}

void CoutReverse(node* head, node* tail) {
	for (node* cur = tail; cur != NULL; cur = cur->prev) {
		cout << cur->num << " ";
	}
}

bool FindPerfect(int a) { // функция нахождения совершенного числа
	bool x; // возвращаем логическое значение
	int sum = 0, c;
	for (int i = 1; i <= (a / 2); i++) {
		c = a % i;
		if (c == 0) sum = sum + i;
	}
	if (sum == a) x = 1; // если число совершенно, возвращаем правду
	else x = 0; // если число не совершенно, возвращаем ложь
	return x; // возвращаем логическое значени
}

void TabuTask(node* head, node* tail) { // функция добавления узлов после совершенного числа
	node* newnode; // создание вспомогательного числа
	for (node* cur = head; cur != NULL; cur = cur->next) { // пока список не кончился
		bool b = FindPerfect(cur->num); // определение совершенного числа
		if (b == true) { // если число совершенно
			for (int i = 0; i < 3; i++) { // добавляем три узла после узла с совершенным числом
				newnode = new node;
				newnode->num = tail->num + rand();
				newnode->next = cur->next;
				newnode->prev = cur;
				cur->next->prev = newnode;
				cur->next = newnode;

			}
		}
	}
}

int main()
{
	setlocale(LC_ALL, "russian");
	ifstream in; // создание объекта для чтения текстового файла
	in.open("file.txt"); // открытие текстового файла
	if (!in.is_open()) { // проверка наличия файла
		cout << "Ошибка открытия файла!\nПричина: файл отсутствует или неверно указанно его имя.\nПроверьте наличие файла или его имя.";
		exit(0);
	}
	node* head = NULL, * tail = NULL, * newNode;// создаем три узла: голову, хвост и вспомогательный
	while (!in.eof()) {// считывание списка с файла
		newNode = new node;// создаем узел
		in >> newNode->num; // считываем число в узел
		newNode->next = NULL;
		newNode->prev = NULL;
		if (tail == NULL) {
			head = newNode;
			tail = newNode;
		}
		else {
			tail->next = newNode;
			newNode->prev = tail;
			tail = newNode;
		}
	}
	in.close();// закрытие файла
	cout << "Вывод списка в обычном порядке" << endl;
	CoutNormal(head, tail);// вывод списка
	cout << endl;
	cout << "Вывод списка в обратном порядке" << endl;
	CoutReverse(head, tail);// то же самое, только в обратном порядке
	cout << endl;
	TabuTask(head, tail); // изменение списка в связи с условием задачи
	cout << "Вывод измененного списка в обычном порядке" << endl;
	CoutNormal(head, tail);// опять вывод списка
	cout << endl;
	cout << "Вывод измененного списка в обратном порядке" << endl;
	CoutReverse(head, tail);// опять то же самое, только в обратном порядке
	return 0;
}