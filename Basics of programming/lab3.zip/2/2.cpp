﻿//Базаров Алмазбек Султанбаевич
// КИ20-07б(1 подгруппа)
//сложность : 100%
//2 вариант
// Дано три целых числа, определяющих календарную дату (день, месяц и год). Вывести следующую за введенной календарную дату (день, месяц и год).

#include <iostream>
#include <iomanip>
#include <clocale>
using namespace std;

int main() {
    setlocale(LC_ALL, "russian");
    int year, month, day;
    year = -7; month = -7; day = -7;
    cout << "Вас приветствует автоматизированный календарь 'Любовь - 3'.\n";
    cout << "Обозначения: 11-да, 00-нет.\nНачнём.\n\n";
beriNers:
    cout << "Введите год (пример : 1995):";
cinYear:
    cin >> year;
    if (year < 1) {
        cout << "Введено неверное значение , попробуйте еще :";
        goto cinYear;
    }
    cout << "Введите месяц (пример : 05):";
cinMonth:
    cin >> month;
    if (month > 12 || month < 1) {
        cout << "Введено неверное значение , попробуйте еще :";
        goto cinMonth;
    }
    switch (month) {
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    case 12:
    {
        cout << "Введите день от 01 до 31 (пример : 26):";
    cinDay31:
        cin >> day;
        if (day > 31 || day < 1) {
            cout << "Введено неверное значение , попробуйте еще :";
            goto cinDay31;
        }
        break;
    }
    case 4:
    case 6:
    case 9:
    case 11:
    {
        cout << "Введите день от 01 до 30 (пример : 26):";
    cinDay30:
        cin >> day;
        if (day > 30 || day < 1) {
            cout << "Введено неверное значение , попробуйте еще :";
            goto cinDay30;
        }
        break;
    }
    case 2:
    {
        if (year % 4 == 0) {
            cout << "Введите день от 01 до 29 (пример : 26):";
        cinDay29:
            cin >> day;
            if (day > 29 || day < 1) {
                cout << "Введено неверное значение , попробуйте еще :";
                goto cinDay29;
            }
        }
        else {
            cout << "Введите день от 01 до 28 (пример : 26):";
        cinDay28:
            cin >> day;
            if (day > 28 || day < 1) {
                cout << "Введено неверное значение , попробуйте еще :";
                goto cinDay28;
            }
        }

    }
    break;
    }
    switch (month) {
    case 1:
    case 3:
    case 5:
    case 7:
    case 8:
    case 10:
    {
        if (day == 31) {
            day = 1;
            month = month + 1;
        }
        else day = day + 1;
        break;
    }
    case 4:
    case 6:
    case 9:
    case 11:
    {
        if (day == 30) {
            day = 1;
            month = month + 1;
        }
        else day = day + 1;
        break;
    }
    case 12:
    {
        if (month == 12 && day == 31) {
            year = year + 1;
            month = 1;
            day = 1;
        }
        else  day = day + 1;
        break;
    }
    case 2:
    {
        if (year % 4 == 0) {
            if (day == 29) {
                month = month + 1;
                day = 1;
            }
            else day = day + 1;
        }
        else {
            if (day == 28) {
                month = month + 1;
                day = 1;
            }
            else day = day + 1;
        }
        break;
    }
    }
    if (month < 10 && day < 10) {
        cout << "Следующая дата :";
        cout << year << ".0" << month << ".0" << day << endl;
    }
    if (month < 10 && day > 9) {
        cout << "Следующая дата :";
        cout << year << ".0" << month << "." << day << endl;
    }
    if (month > 9 && day < 10) {
        cout << "Следующая дата :";
        cout << year << "." << month << ".0" << day << endl;
    }
    if (month > 9 && day > 9) {
        cout << "Следующая дата :";
        cout << year << "." << month << "." << day << endl;
    }

    cout << "\nАвтоматизированный календарь 'Любовь - 3' завершил работу.";
    return 0;
}