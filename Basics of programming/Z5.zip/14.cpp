﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 14 (Z5)
/*Дано натуральное число N и действительное число x. Определить P=∏i=1N2xi. Функцию pow() или её аналоги не использовать..*/

#define _CRT_SECURE_NO_WARNINGS
#include <clocale>
#include <iostream>
#include <stdio.h>
#include <conio.h>

int main()
{
    setlocale(LC_ALL, "russian");
    float x, S, m;
    int N;
    printf("Введите натуральное N :");
    scanf("%d",&N);
    printf("Введите действительное x :");
    scanf("%f", &x);
    S = 1;
    for (int i = 1 ; i <= N; i++) {
        m = 1;
        for (int j = 1; j <= i; j++) { m = m * x; }
        float m1 = 2 * m;
        S = S * m1;
    }
    printf("S = %.1f",S);
    return 0;
}