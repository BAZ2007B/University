﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 13 (Z5)
/*Дано натуральное число N. Определить S=∑i=1Nii+1. Вычисление i/(i+1) оформить как функцию double ai(int i)..*/

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <clocale>
#include <stdio.h>
#include <conio.h>

double ai(int i) {
    double m = i;
    double j = i + 1;
    double f = (m/j);
    return f;
}

int main()
{
    setlocale(LC_ALL,"russian");
    double S , m;
    int N;
    printf("Введите N:");
    scanf("%d", &N);
    S = 0;
    for (int i = 1; i <= N; i++) {
        m = ai(i);
        S = S + m;
    }
    printf("S = %.2lf", S);
    return 0;
}

