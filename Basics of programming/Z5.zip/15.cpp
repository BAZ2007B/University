﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 15 (Z5)
/* Дано натуральное число N. Определить S=∑i=1Nis(i), где s(i)={1,−1если i — чётноеиначе. Проверку чётности i, функцию pow() или её аналоги не использовать..*/

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <clocale>
#include <stdio.h>
#include <conio.h>
using namespace std;

int main()
{
    setlocale(LC_ALL, "russian");
    int S, N, a;
    cout << "Введите N :";
    cin >> N;
    S = 0;
    for (int i = 1; i <= N; i++) {
        a = i;
        if (a % 2 == 0) { a = i; }
        else { a = a * (-1); }
        S = S + a;
    }
    cout << "S = "<< S;
    return 0;
}

