﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 11 (Z4)
/* Дано целое число s. Вывести диагональную линию из символов «*» из левого верхнего угла в области из s строк и s столбцов. 
Вывод линии оформить как функцию void print_diag(int s).*/

#include <clocale>
#include <iostream>
#include <math.h>
using namespace std;

void print_diag(int s) {
    for (int i = 0; i < s; i++) {
        int m = 0;
        while (m < i) { cout << " "; m++; }
        cout << "*" << endl;
    }
}

int main()
{
    setlocale(LC_ALL,"russian");
    int a;
    cout << "Введите s :";
    cin >> a;
    a = abs(a);
    print_diag(a);
}

