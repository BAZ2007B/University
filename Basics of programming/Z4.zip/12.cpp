﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 12 (Z4)
/* Даны целые числа x, y, sx, sy. Вывести прямоугольник из символов «@» с размерами sx по горизонтали, 
sy по вертикали, левый верхний угол которого находится в точке с координатами (x, y). 
Ось X направлена вправо, ось Y — вниз. Начало координат находится в левом верхнем углу в точке (0,0). 
Вывод прямоугольника оформить как функцию void print_rect(int x, int y, int sx, int sy).*/


#include <clocale>
#include <iostream>
using namespace std;

void print_rect(int x, int y, int sx, int sy) {
    for (int i = 0; i < y; i++) {
        cout << endl;
    }
    for (int j = 0; j < sy; j++) {
        int m = 0;
        while (m < x) { cout << " "; m++; }
        int k = x;
        int p = sx + x;
        while (k < p) { cout << "@"; k++; }
        cout << endl;
    }
}

int main()
{
    setlocale(LC_ALL,"russian");
    int a, b, c, d;
    cout << "Введите x :";
    cin >> a;
    cout << "Введите y :";
    cin >> b;
    cout << "Введите sx :";
    cin >> c;
    cout << "Введите sy :";
    cin >> d;
    print_rect(a, b, c, d);
}
