﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 21 (Z7)
/* Написать функцию int splice_array(int arr1[], int arr2[], int len, int arr_out[]), которая соединяет массивы arr1[], arr2[] размера len
путём чередования элементов (arr1[0], arr2[0], arr1[1], arr2[1], ...) и помещает результат в arr_out[]. Функция должна возвращать размер
получившегося массива.*/

#include <iostream>
#include <clocale>
using namespace std;

int* read_array(int len) {
    int* arr = new int[len];
    for (int i = 0; i < len; i++) cin >> arr[i];
    return arr;
}

void print_array(int arr[], int len) {
    for (int i = 0; i < len; i++) cout << arr[i] << " ";
    cout << endl;
}

int splice_array(int arr1[], int arr2[], int len, int arr_out[]) {
    int lenC = 2 * len;
    int j = 0;
    for (int i = 0; i < lenC; i = i + 2) {
        arr_out[i] = arr1[j];
        arr_out[i + 1] = arr2[j];
        j++;
    }
    return lenC;
}

int main() {
    setlocale(LC_ALL, "russian");
    int len;
    int* a;
    int* b;
    cout << "Введите размер для массивов A и B:";
    cin >> len;
    cout << "Введите массив A:" << endl;
    a = read_array(len);
    cout << "Введите массив B:" << endl;
    b = read_array(len);
    int lenC = len * 2;
    int* c = new int[lenC];
    lenC = splice_array(a, b, len, c);
    cout << "Массив C состоит из:" << endl;
    print_array(c, lenC);
    return 0;
}