﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 16 (Z6)
/* Протабулировать функцию f(x)=2x2−3x+1 на отрезке [a;b] с шагом s. Вычисление f(x) оформить как функцию double f(double x).*/

#include <iostream>
#include <iomanip>
#include <clocale>
#include <stdio.h>
#include <conio.h>
#include <math.h>
using namespace std;

double f(double x) {
    double a = 2*x*x;
    double b = a - (3 * x) + 1;
    return b;
}

int main()
{
    setlocale(LC_ALL, "russian");
    double A, B, s, fx;
    cout << "Введите A(Начало отрезка):";
    cin >> A;
TryAgain:
    cout << "Введите B(Конец отрезка):";
    cin >> B;
    if (B <= A) {
        cout << "B не может быть больше , повторите.\n";
        goto TryAgain;
    }
    cout << "Введите s(Шаг отрезка):";
    cin >> s;
    for (A; A <= B; A = A + s) {
        fx = f(A);
            cout.setf(ios::left);
            cout << fixed << setw(10) << A;
            cout << " ";
            cout << scientific << setw(15) << fx << endl;
    }
    return 0;
}


