﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 18 (Z6)
/* Протабулировать функцию f(x)=sin2(πx) на отрезке [a;b] с шагом s. Вычисление f(x) оформить как функцию double f(double x).
Значение числа π для расчётов определить с помощью стандартной функции арккосинуса (std::acos()) и сохранить внутри функции f()
в виде статической константы static const double pi.*/

#include <iostream>
#include <iomanip>
#include <clocale>
#include <stdio.h>
#include <conio.h>
#include <math.h>
using namespace std;

double f(double x) {
    static const double Pi = acos(-1);
    double Sinx = sin(Pi * x);
    double a = Sinx * Sinx;
    return a;
}

int main()
{
    setlocale(LC_ALL, "russian");
    double A, B, s, scale, y;
    int v;
    cout << "Введите A(Начало отрезка):";
    cin >> A;
TryAgain:
    cout << "Введите B(Конец отрезка):";
    cin >> B;
    if (B <= A) {
        cout << "B не может быть больше , повторите.\n";
        goto TryAgain;
    }
    cout << "Введите s(Шаг отрезка):";
    cin >> s;
    cout << "Введите scale(Масштабный коэффициент):";
    cin >> scale;
    double u = 0;
    for (A ; A < B ;A = A + s) {
        y = f(A);
        v = scale * y;
        cout << setw(v) << "";
        cout << "$(" << A << ". "  << y << ")" << endl;
        u = u + s;
    }
    return 0;
}
