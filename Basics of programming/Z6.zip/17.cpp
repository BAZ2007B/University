﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 17 (Z6)
/* Протабулировать функцию f(x)=5x+2 на отрезке [a;b] с шагом s. Вычисление f(x) оформить как функцию double f(double x).*/

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <iomanip>
#include <clocale>
#include <stdio.h>
#include <conio.h>
#include <math.h>
using namespace std;

double f(double x) {
    double a = 5 * x + 2;
    return a;
}

int main()
{
    setlocale(LC_ALL, "russian");
    double A, B, s, fx;
    cout << "Введите A(Начало отрезка):";
    cin >> A;
TryAgain:
    cout << "Введите B(Конец отрезка):";
    cin >> B;
    if (B <= A) {
        cout << "B не может быть больше , повторите.\n";
        goto TryAgain;
    }
    cout << "Введите s(Шаг отрезка):";
    cin >> s;
    double C = A;
    for (A; A <= B; A = A + s) {
        cout << fixed << setprecision(3) << setw(15) << A;
    }
    cout << endl;
    for (C; C <= B; C = C + s) {
        fx = f(C);
        cout << scientific << setprecision(5) << setw(15) << fx;
    }
    return 0;
}