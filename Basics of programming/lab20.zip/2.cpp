﻿//Базаров Алмазбек Султанбаевич
// КИ20-07б(1 подгруппа)
//сложность : 100%
//2 вариант
/*
Название БД:Права пользователей.Записать в двоичный файл данные о пользователях, сгруппированные по их роли: 
сначала простые пользователи, потом модераторы и администраторы
*/

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <clocale>
#include <cstring>
using namespace std;

struct Specification { // структура характеристики пользователя
    char Surname[60];// фамилия
    char Login[40];// логин
    char Password[40];// пароль
    int Right;// права пользователя
};

class Base { // определения класса базы данных одного пользователя
private: // уровень доступа - приватный: вне класса без специальных методов менять нельзя
    Specification User; //тип данных пользователя - структура
public:// уровень доступа - публичный: вне класса можно взаимодействовать
    // здесь мы определяем поведение объекта класса
    int ReturnRight() { // возвращает права пользователя
        return User.Right;
    }
    void GetData(ifstream& in) { // считываение данных из текстового файла в аттрибуты объекта класса
        in >> User.Surname;
        in >> User.Login;
        in >> User.Password;
        in >> User.Right;
    }
    void Cout() { // вывод аттрибутов объекта класса
        cout << User.Surname << ' ' << User.Login << ' ' << User.Password << ' ' << User.Right << endl;
    }
    void WriteBin(ofstream& ost) { // запись аттрибутов объекта класса в двоичный файл
        ost.write((char*)&User, sizeof(Specification));
    }
    void ReadBin(ifstream& ist) { // чтение данных из двоичного файла в аттрибуты объекта класса
        ist.read((char*)&User, sizeof(Specification));
    }
};

int main()
{
    setlocale(LC_ALL, "russian");
    ifstream textist; // объект для чтения текстового файла
    textist.open("in.txt");// открываем его 
    // Экстренный выход из программы, если файл in.txt отсутствует
    if (!textist.is_open()) {
        cout << "Ошибка открытия файла!\nПричина: файл отсутствует или неверно указанно его имя.\nПроверьте наличие файла или его имя.";
        exit(0);
    }
    char* str = new char[170];// массив символов для чтения строки
    int n = 0;// количество пользоваетелй
    while (!textist.eof()) { textist.getline(str, 170, '\n'); n++; } // определение количества пользователей
    textist.seekg(0, ios_base::beg); // возвращение на начальную позицию
    Base* User = new Base[n]; // создание массива объектов класса (пользователи)
    delete[]str;// удаляем строку за ненадобностью, освобождение памяти
    for (int i = 0; i < n; i++)
        User[i].GetData(textist); // чтение данных из текстового файла в аттрибуты каждого объекта класса 
    cout << "Текстовый файл:" << endl;
    for (int i = 0; i < n; i++)
        User[i].Cout(); // вывод аттрибутов объектов класса
    textist.close(); // закрываем текстовый файл
    ofstream ost("in_bin.txt", ios_base::binary | ios::trunc); // объект для записи двоичного файла
    for (int i = 0; i <= 3; i++)
        for (int j = 0; j < n; j++) {
            if (User[j].ReturnRight() == i) User[j].WriteBin(ost);// записываем в двоичный файл данные о 
                                                                  //пользователях в порядке возрастания прав
        }
    ost.close();// закрываем двоичный файл
    delete[]User; // удаляем массив объектов класса
    ifstream ist("in_bin.txt", ios_base::binary); // объект для чтения двоичного файла
    Base* NewUser = new Base[n];// создаем массив объектов класса для чтения данных из двоичного файла
    for (int i = 0; i < n; i++) NewUser[i].ReadBin(ist); // чтение данных из двоичного файла в каждый объект массива класса
    ist.close(); // закрываем двоичный файл
    cout << "Двоичный файл:" << endl;
    for (int i = 0; i < n; i++)
        NewUser[i].Cout();// вывод аттрибутов объектов класса
    delete[]NewUser; // удаляем массив объектов класса
    return 0;
}
