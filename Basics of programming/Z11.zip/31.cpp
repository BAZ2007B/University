﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 31 (Z11)
/* Написать функцию int **make2d(size_t nrows, size_t ncols, int val), которая возвращает динамический двумерный массив целых чисел из nrows
строк и ncols столбцов, элементы которого равны val.*/

#include <iostream>
using namespace std;

int** make2d(size_t nrows, size_t ncols, int val) {
	int** arr = new int* [nrows];
	for (int i = 0; i < nrows; i++) {
		arr[i] = new int[ncols];
	}
	for (int i = 0; i < nrows; i++)
		for (int j = 0; j < ncols; j++)
			arr[i][j] = val;
	return arr;
}

void PrintArray(int** const arr, size_t nrows, size_t ncols) {
	for (int i = 0; i < nrows; i++) {
		for (int j = 0; j < ncols; j++) {
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}

int main()
{
	int nrows, ncols, val;
	cout << "Enter rows:";
	cin >> nrows;
	cout << "Enter cols:";
	cin >> ncols;
	cout << "Enter value:";
	cin >> val;
	int** arr = make2d(nrows, ncols, val);
	PrintArray(arr, nrows, ncols);
	for (int i = 0; i < nrows; i++) {
		delete[] arr[i];
	}
	delete[] arr;
	return 0;
}
