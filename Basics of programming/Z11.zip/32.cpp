﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 32 (Z11)
/* Написать функцию void fliplr(int **arr, size_t nrows, size_t ncols), которая переворачивает двумерный массив целых чисел из nrows строк 
и ncols столбцов слева направо.*/

#include <iostream>
using namespace std;

int** make2d(size_t nrows, size_t ncols) {
	int** arr = new int* [nrows];
	for (int i = 0; i < nrows; i++) {
		arr[i] = new int[ncols];
	}
	for (int i = 0; i < nrows; i++) {
		cout << "Enter through space " << i+1 << " row:";
		for (int j = 0; j < ncols; j++) cin >> arr[i][j];
	}
	return arr;
}

void fliplr(int** arr, size_t nrows, size_t ncols) {
	int t, a = ncols % 2;
	if (a == 1) a = (ncols - 1) / 2;
	else a = ncols / 2;
	for (int i = 0; i < nrows; i++)
		for (int j = 0; j < a; j++) {
			t = arr[i][j];
			arr[i][j] = arr[i][ncols - j-1];
			arr[i][ncols - j-1] = t;
		}
}

void PrintArray(int** const arr, size_t nrows, size_t ncols) {
	for (int i = 0; i < nrows; i++) {
		for (int j = 0; j < ncols; j++) {
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}

int main()
{
	int nrows, ncols;
	cout << "Enter rows:";
	cin >> nrows;
	cout << "Enter cols:";
	cin >> ncols;
	int** arr = make2d(nrows, ncols);
	PrintArray(arr, nrows, ncols);
	cout << endl;
	fliplr(arr, nrows, ncols);
	PrintArray(arr, nrows, ncols);
	for (int i = 0; i < nrows; i++) {
		delete[] arr[i];
	}
	delete[] arr;
	return 0;
}
