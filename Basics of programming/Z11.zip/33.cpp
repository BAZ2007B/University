﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 33 (Z11)
/* Написать функцию void transpose(int **arr, size_t size), которая транспонирует квадратную матрицу целых чисел порядка size.*/

#include <iostream>
using namespace std;

int** FillArray(int const size) {
	int** arr = new int* [size];
	for (int i = 0; i < size; i++) {
		arr[i] = new int[size];
	}
	for (int i = 0; i < size; i++) {
		cout << "Enter through space " << i + 1 << " row:";
		for (int j = 0; j < size; j++) cin >> arr[i][j];
	}
	return arr;
}

void transpose(int** arr, size_t size) {
	int t;
	for (int i = 0; i < size; i++)
		for (int j = i; j < size; j++) {
			t = arr[i][j];
			arr[i][j] = arr[j][i];
			arr[j][i] = t;
		}
}

void PrintArray(int** const arr, int const n) {
	for (int i = 0; i < n; i++) {
		for (int j = 0; j < n; j++) {
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}

int main()
{
	int size;
	cout << "Enter size:";
	cin >> size;
	int** arr = FillArray(size);
	cout << endl;
	cout << "Usual matrix" << endl;
	PrintArray(arr, size);
	cout << endl;
	transpose(arr, size);
	cout << "Transposed matrix" << endl;
	PrintArray(arr, size);
	for (int i = 0; i < size; i++) {
		delete[] arr[i];
	}
	delete[] arr;
	return 0;
}
