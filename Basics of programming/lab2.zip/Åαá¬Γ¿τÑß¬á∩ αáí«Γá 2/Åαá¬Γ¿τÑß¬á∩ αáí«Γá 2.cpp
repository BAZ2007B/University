﻿// Базаров Алмазбек Султанбаевич
// КИ20-07б(1 подгруппа)
// 20% - хорошая
// 2 вариант

#include <iostream>
#include <clocale>

int main()
{
    setlocale(LC_ALL, "russian");
    int V1, V2, T, S, S_end1;
    float S_end2;
    printf("Введите последовательно через пробел V1, V2, T и S:");
    scanf_s("%d%d%d%d", &V1, &V2, &T, &S);
    S_end1 = S - V1 * T - V2 * T;
    printf("Конечное расстояние = %d", S_end1);
    printf("\nКонечное расстояние = %10d", S_end1);
    printf("\nКонечное расстояние = %-10d", S_end1);
    S_end2 = (float)S_end1;
    printf("\nКонечное расстояние = %f", S_end2);
    printf("\nКонечное расстояние = %15.4f", S_end2);
    printf("\nКонечное расстояние = %-15.4f", S_end2);
    printf("\nКонечное расстояние = %0.15f", S_end2);
    printf("\nКонечное расстояние = %30.15f", S_end2);
    return 0;
}