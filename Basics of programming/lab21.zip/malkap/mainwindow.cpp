#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "baza.h"
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <clocale>
#include <cstring>
using namespace std;

#include <QMessageBox>
#include <QString>
#include <QStringList>
#include <QListWidget>
#include <QFileDialog>

MainWindow::MainWindow(QWidget *parent)
    : QMainWindow(parent)
    , ui(new Ui::MainWindow)
{
    ui->setupUi(this);
}

MainWindow::~MainWindow()
{
    delete ui;
}

void MainWindow::on_ReviewText_clicked()// при нажатии кнопки обзор для текстового файла
{
    QString directory = QFileDialog::getOpenFileName(this, tr("Выберите файл"), "/", tr("*.txt"));
    ui->textEditText->setText(directory); // указываем в строке путь файла
}

void MainWindow::on_ReviewBin_clicked() // при нажатии кнопки обзор для двоичного файла
{
    QString directory = QFileDialog::getOpenFileName(this, tr("Выберите файл"), "/", tr("*.dat"));
    ui->textEditBin->setText(directory); // указываем в строке путь файла
}

void MainWindow::on_ModeText_clicked() // режим 1
{
    QString stringtext = ui->textEditText->toPlainText().trimmed(); // чтение строки
    string strokatext = stringtext.toLocal8Bit().constData(); // имя текстового файла
    QString stringbin = ui->textEditBin->toPlainText().trimmed(); // чтение строки
    string strokabin = stringbin.toLocal8Bit().constData(); // имя двоичного файла
    ifstream textist ; // объект для чтения текстового файла
    textist.open(strokatext);// открываем его
    if (!textist.is_open()) { // если файл не открывается(неверное имя или не указан)
        QMessageBox::critical(this,"Info","Текстовый файл не найден!");
        return void(); // закрывает режим
    }
    ofstream ost(strokabin, ios_base::binary | ios::trunc); // объект для записи двоичного файла
    if (!ost.is_open()) { // если файл не открывается(неверное имя или не указан)
        QMessageBox::critical(this,"Info","Двоичный файл не найден!");
        return void(); // закрывает режим
    }
    char* str = new char[170]; // строка для чтения строк из файла
    int n = 0; // количество пользователей
        while(!textist.eof()) { textist.getline(str, 170, '\n'); n++; } // определение количества пользователей
    textist.seekg(0, ios_base::beg); // возвращение на начальную позицию
    Base* User = new Base[n]; // создание массива объектов класса (пользователи)
    delete[]str;// удаляем строку за ненадобностью, освобождение памяти
    for (int i = 0; i < n; i++) // считаем пользователей
        User[i].GetData(textist);
    textist.close(); // закрываем текстовый файл
    ui->listWidget->clear(); // очищаем окно
    ui->listWidget->addItem("Текстовый файл:");
    string zak;
    for (int i =0 ; i < n; i++) { // необычное решение
        zak = "";
        zak = User[i].ToStr();
        QString Agas = QString::fromStdString(zak); // из string в QString
        ui->listWidget->addItem(Agas); // выводим пользователя в окно
    }
    for (int i = 0; i <= 3; i++)
            for (int j = 0; j < n; j++) {
                if (User[j].ReturnRight() == i) User[j].WriteBin(ost);// записываем в двоичный файл данные о
                                                                      //пользователях в порядке возрастания прав
            }
    ost.close();// закрываем двоичный файл
    delete []User; // удаляем пользователей, очищаем память
}

void MainWindow::on_ModeBin_clicked()
{
    QString stringtext = ui->textEditText->toPlainText().trimmed();// чтение строки
    string strokatext = stringtext.toLocal8Bit().constData();// имя текстового файла
    QString stringbin = ui->textEditBin->toPlainText().trimmed();// чтение строки
    string strokabin = stringbin.toLocal8Bit().constData();// имя двоичного файла
    ifstream textist ; // объект для чтения текстового файла (только длля определения количества пользователей)
    textist.open(strokatext);// открываем его
    if (!textist.is_open()) {// если файл не открывается(неверное имя или не указан)
        QMessageBox::critical(this,"Info","Текстовый файл не найден!");
        return void();// закрывает режим
    }
    ifstream ist(strokabin, ios_base::binary);
    if(!ist.is_open()){// если файл не открывается(неверное имя или не указан)
        QMessageBox::critical(this,"Info","Двоичный файл не найден!");
        return void();// закрывает режим
    }
    char* str = new char[170]; // строка для чтения строк из файла
    int n = 0;// количество пользователей
        while(!textist.eof()) { textist.getline(str, 170, '\n'); n++; }// определение количества пользователей
    textist.close(); // закрытие текстового файла
    delete[]str;// удаляем строку за ненадобностью, очищаем память
    Base* NewUser = new Base[n];// создаем массив объектов класса для чтения данных из двоичного файла
        for (int i = 0; i < n; i++) NewUser[i].ReadBin(ist); // чтение данных из двоичного файла в каждый объект массива класса
    ist.close(); // закрываем двоичный файл
    ui->listWidget->clear(); // очищаем окно
    ui->listWidget->addItem("Двоичный файл:");
    string zak;
    for (int i =0 ; i < n; i++) { // снова необычное решение
        zak = "";
        zak = NewUser[i].ToStr();
        QString Agas = QString::fromStdString(zak);// из string в QString
        ui->listWidget->addItem(Agas);// выводим пользователя в окно
    }
    delete[] NewUser;// удаляем пользователей, очищаем память
}
