#ifndef BAZA_H
#define BAZA_H
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <clocale>
#include <cstring>
using namespace std;

struct Specification { // структура характеристики пользователя
    char Surname[60];// фамилия
    char Login[40];// логин
    char Password[40];// пароль
    int Right;// права пользователя
};

class Base { // определения класса базы данных одного пользователя
private: // уровень доступа - приватный: вне класса без специальных методов менять нельзя
    Specification User; //тип данных пользователя - структура
public:// уровень доступа - публичный: вне класса можно взаимодействовать
    // здесь мы определяем поведение объекта класса
    int ReturnRight() { // возвращает права пользователя
        return User.Right;
    }
    void GetData(ifstream& in) { // считываение данных из текстового файла в аттрибуты объекта класса
        in >> User.Surname;
        in >> User.Login;
        in >> User.Password;
        in >> User.Right;
    }
    void Cout() { // вывод аттрибутов объекта класса
        cout << User.Surname << ' ' << User.Login << ' ' << User.Password << ' ' << User.Right << endl;
    }
    void WriteBin(ofstream& ost) { // запись аттрибутов объекта класса в двоичный файл
        ost.write((char*)&User, sizeof(Specification));
    }
    void ReadBin(ifstream& ist) { // чтение данных из двоичного файла в аттрибуты объекта класса
        ist.read((char*)&User, sizeof(Specification));
    }
    string ToStr(){ // метод превращения данных пользователя в одну строку (для вывода в окно QListWidget)
        string total ="";
        total = total + User.Surname;
        total = total + " ";
        total = total + User.Login;
        total = total + " ";
        total = total + User.Password;
        total = total + " ";
        if (User.Right == 0) total = total+"0";
        if (User.Right == 1) total = total+"1";
        if (User.Right == 2) total = total+"2";
        if (User.Right == 3) total = total+"3";
        return total;
    }
};

#endif // BAZA_H
