#include "baza.h"
#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <clocale>
#include <cstring>
using namespace std;

Baza::Baza()
{
    struct Specification { // структура характеристики пользователя
        char Surname[60];// фамилия
        char Login[40];// логин
        char Password[40];// пароль
        int Right;// права пользователя
    };

    class Base { // определения класса базы данных одного пользователя
    private: // уровень доступа - приватный: вне класса без специальных методов менять нельзя
        Specification User; //тип данных пользователя - структура
    public:// уровень доступа - публичный: вне класса можно взаимодействовать
        // здесь мы определяем поведение объекта класса
        int ReturnRight() { // возвращает права пользователя
            return User.Right;
        }
        void GetData(ifstream& in) { // считываение данных из текстового файла в аттрибуты объекта класса
            in >> User.Surname;
            in >> User.Login;
            in >> User.Password;
            in >> User.Right;
        }
        void Cout() { // вывод аттрибутов объекта класса
            cout << User.Surname << ' ' << User.Login << ' ' << User.Password << ' ' << User.Right << endl;
        }
        void WriteBin(ofstream& ost) { // запись аттрибутов объекта класса в двоичный файл
            ost.write((char*)&User, sizeof(Specification));
        }
        void ReadBin(ifstream& ist) { // чтение данных из двоичного файла в аттрибуты объекта класса
            ist.read((char*)&User, sizeof(Specification));
        }
    };
}
