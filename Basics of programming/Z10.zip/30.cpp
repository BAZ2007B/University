﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 30 (Z10)
/*Написать функцию std::size_t join(char *s_out, std::size_t len, const char * const *s_in, std::size_t n_in, const char *sep), которая
соединяет n_in строк из массива строк s_in в одну строку s_out длины не более len символов, разделяя их строкой sep. Если длина соединённой
строки превышает len, строка обрезается до нужной длины. Строка s_out должна заканчиваться нулевым символом ('\0'). Функция возвращает
эффективную длину строки (до нулевого символа).*/

#include <string>
#include <iostream>
using namespace std;

void join(string& s_out, size_t len, const string* s_in, size_t n_in, const string& sep) {
    for (int i = 0; i < n_in - 1; i++) {
        s_out = s_out + s_in[i] + sep;
    }
    s_out = s_out + s_in[n_in - 1];
    s_out.resize(len);
}

int main()
{
    int size, len, ling;
    cout << "Enter an array size:";
    cin >> size;
    string total = "", sep;
    string *arr = new string [size];
    getline(cin, arr[0]);
    for (int i = 0; i < size; i++) {
        cout << "Enter a string and press button enter:";
        getline(cin, arr[i]);
    }
    cout << "Enter separating symbols:";
    getline(cin, sep);
    cout << "Enter total string length:";
    cin >> len;
    cout << "Enter how many string you want use:";
    TryAgain:
    cin >> ling;
    if (ling > size) {
        cout << "You cannot use more lines than there are[size], re-enter:";
        goto TryAgain;
    }
    join(total,len,arr,ling,sep);
    cout << total << endl;
    return 0;
}
