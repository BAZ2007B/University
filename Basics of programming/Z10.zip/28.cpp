﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 28 (Z10)
/* Написать функцию void rstrip(char *s, const char *chars), которая удаляет из конца строки s символы, входящие в строку chars.*/

#include <string>
#include <iostream>
using namespace std;

void rstrip(string& s, string const& chars) {
    int num = 0;
    for (int i = s.size() - 1; i >= 0; i--) {
        if (s.substr(i, 1) == " ") {
            if (s.substr(i - 2, 1) == s.substr(i, 1)) continue;
            num = i;
            break;
        }
    }
    for (int i = num; i < s.size(); i++) {
        TryAgain:
        for (int j = 0; j < chars.size(); j++) 
        {
            while (s.substr(i, 1) == chars.substr(j, 1))
                s.erase(i, 1);
        };
        for (int j = 0; j < chars.size(); j++) 
        {
            if (s.substr(i, 1) == chars.substr(j, 1)) goto TryAgain;
        }
    }
}

int main()
{
    string s, chars;
    cout << "Enter String:";
    getline(cin, s);
    cout << "Enter Chars:";
    getline(cin, chars);
    rstrip(s, chars);
    cout << s;
    return 0;
}