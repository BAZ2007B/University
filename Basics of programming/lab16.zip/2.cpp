﻿//Базаров Алмазбек Султанбаевич
// КИ20-07б(1 подгруппа)
//сложность : 100%
//2 вариант
/*
Название БД - Права пользователей. Записать в двоичный файл данные опользователях, сгруппированные по их роли: сначала простые пользователи, 
потом модераторы и администраторы
*/

#define _CRT_SECURE_NO_WARNINGS
#include <iostream>
#include <fstream>
#include <clocale>
#include <cstring>
using namespace std;

enum Rights {
    nothing,
    simple_user,
    moderator,
    administrator,
};

struct Users {
    char Surname[60];
    char Login[40];
    char Password[40];
    int IntRight;
    Rights Right;
};

int main()
{
    setlocale(LC_ALL, "russian");
    ifstream textist; // объект для чтения текстового файла
    textist.open("in.txt");
    // Экстренный выход из программы, если файл in.txt отсутствует
    if (!textist.is_open()) {
        cout << "Ошибка открытия файла!\nПричина: файл отсутствует или неверно указанно его имя.\nПроверьте наличие файла или его имя.";
        exit(0);
    }
    char* str = new char[170];
    int n = 0;
    while (!textist.eof()) { textist.getline(str, 170, '\n'); n++; } // определение количества пользователей
    textist.seekg(0, ios_base::beg); // возвращение на начальную позицию
    Users* User = new Users[n]; // создание массива пользователей 
    for (int i = 0; i < n; i++) {
        str[0] = 0;
        textist >> User[i].Surname;
        textist >> User[i].Login;
        textist >> User[i].Password;
        textist >> str;
        if (str[0] == 's') { User[i].Right = simple_user; User[i].IntRight = 1; }
        if (str[0] == 'm') { User[i].Right = moderator; User[i].IntRight = 2; }
        if (str[0] == 'a') { User[i].Right = administrator; User[i].IntRight = 3; }
        if ((str[0] == '"') && (str[1] == '"') && (str[2] == '\0')) { User[i].Right = nothing; User[i].IntRight = 0; }
    }
    textist.close();
    cout << "Текстовый файл:" << endl;
    for (int i = 0; i < n; i++)
        cout << User[i].Surname << " " << User[i].Login << " " << User[i].Password << " " << User[i].Right << endl;
    ofstream ost("in_bin.txt", ios_base::binary | ios::trunc); // объект для записи двоичного файла
    for (int i = 0; i <= 3; i++)
        for (int j = 0; j < n; j++) {
            if (User[j].Right == i) {
                ost.write((char*)&User[j], sizeof(Users));
                /*ost.write((char*)User[j].Surname, sizeof(char) * 60);
                ost.write((char*)User[j].Login, sizeof(char) * 40);
                ost.write((char*)User[j].Password, sizeof(char) * 40);
                ost.write((char*)&j, sizeof(int) * j);*/
            }
        }
    ost.close();
    ifstream ist("in_bin.txt", ios_base::binary); // объект для чтения двоичного файла
    Users* NewUser = new Users[n];
    for (int i = 0; i < n; i++) {
        ist.read((char*)&NewUser[i], sizeof(Users));
        /*ist.read((char*)NewUser[i].Surname, sizeof(char) * 60);
        ist.read((char*)NewUser[i].Login, sizeof(char) * 40);
        ist.read((char*)NewUser[i].Password, sizeof(char) * 40);
        ist.read((char*)NewUser[i].IntRight, sizeof(int) * 1);
        if (NewUser[i].IntRight == 0) NewUser[i].Right = nothing;
        if (NewUser[i].IntRight == 1) NewUser[i].Right = simple_user;
        if (NewUser[i].IntRight == 2) NewUser[i].Right = moderator;
        if (NewUser[i].IntRight >= 3) NewUser[i].Right = administrator;*/
    }
    ist.close();
    delete[]User;
    cout << "Двоичный файл:" << endl;
    for (int i = 0; i < n; i++)
        cout << NewUser[i].Surname << " " << NewUser[i].Login << " " << NewUser[i].Password << " " << NewUser[i].Right << endl;
    return 0;
}
