﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 34 (Z12)
/* Написать функцию void print2d(const int * const *arr, size_t nrows, size_t ncols, std::ostream &ost), которая выводит двумерный массив
целых чисел arr из nrows строк и ncols столбцов в поток ost.*/

#include <iostream>
#include <fstream>
using namespace std;

int** make2d(size_t nrows, size_t ncols, int val) {
	int** arr = new int* [nrows];
	for (int i = 0; i < nrows; i++) {
		arr[i] = new int[ncols];
	}
	for (int i = 0; i < nrows; i++)
		for (int j = 0; j < ncols; j++)
			arr[i][j] = val;
	return arr;
}

void PrintArray(int** const arr, size_t nrows, size_t ncols) {
	for (int i = 0; i < nrows; i++) {
		for (int j = 0; j < ncols; j++) {
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}

void print2d(int** const arr, size_t nrows, size_t ncols, ofstream& ost) {
	ost.open("34.txt");
	for (int i = 0; i < nrows; i++) {
		for (int j = 0; j < ncols; j++) {
			ost << arr[i][j] << " ";
		}
		ost << endl;
	}
	ost.close();
}

int main()
{
	int nrows, ncols, val;
	cout << "Enter rows:";
	cin >> nrows;
	cout << "Enter cols:";
	cin >> ncols;
	cout << "Enter value:";
	cin >> val;
	int** arr = make2d(nrows, ncols, val);
	PrintArray(arr, nrows, ncols);
	ofstream ost;
	print2d(arr, nrows, ncols, ost);
	for (int i = 0; i < nrows; i++) {
		delete[] arr[i];
	}
	delete[] arr;
	return 0;
}