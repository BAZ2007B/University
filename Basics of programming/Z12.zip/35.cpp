﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 35 (Z12)
/* Написать функцию void print_fliplr(const int * const *arr, size_t nrows, size_t ncols, std::ostream &ost), которая выводит в поток ost
перевёрнутый слева направо двумерный массив целых чисел arr из nrows строк и ncols столбцов.*/

#include <iostream>
#include <fstream>
using namespace std;

int** make2d(size_t nrows, size_t ncols) {
	int** arr = new int* [nrows];
	for (int i = 0; i < nrows; i++) {
		arr[i] = new int[ncols];
	}
	for (int i = 0; i < nrows; i++) {
		cout << "Enter through space " << i + 1 << " row:";
		for (int j = 0; j < ncols; j++) cin >> arr[i][j];
	}
	return arr;
}

void fliplr(int** arr, size_t nrows, size_t ncols) {
	int t, a = ncols % 2;
	if (a == 1) a = (ncols - 1) / 2;
	else a = ncols / 2;
	for (int i = 0; i < nrows; i++)
		for (int j = 0; j < a; j++) {
			t = arr[i][j];
			arr[i][j] = arr[i][ncols - j - 1];
			arr[i][ncols - j - 1] = t;
		}
}

void print_fliplr(int** arr, size_t nrows, size_t ncols, ofstream& ost) {
	ost.open("35.txt");
	for (int i = 0; i < nrows; i++) {
		for (int j = 0; j < ncols; j++) {
			ost << arr[i][j] << " ";
		}
		ost << endl;
	}
	ost.close();
}

void PrintArray(int** const arr, size_t nrows, size_t ncols) {
	for (int i = 0; i < nrows; i++) {
		for (int j = 0; j < ncols; j++) {
			cout << arr[i][j] << " ";
		}
		cout << endl;
	}
}

int main()
{
	int nrows, ncols;
	cout << "Enter rows:";
	cin >> nrows;
	cout << "Enter cols:";
	cin >> ncols;
	int** arr = make2d(nrows, ncols);
	PrintArray(arr, nrows, ncols);
	cout << endl;
	fliplr(arr, nrows, ncols);
	PrintArray(arr, nrows, ncols);
	ofstream ost;
	print_fliplr(arr, nrows, ncols, ost);
	for (int i = 0; i < nrows; i++) {
		delete[] arr[i];
	}
	delete[] arr;
	return 0;
}
