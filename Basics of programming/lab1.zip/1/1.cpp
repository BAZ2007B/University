﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//сложность : 100%
//2 вариант
//Написать программу, выводящую на экран два приветствия «Hello world!» и «Привет Мир!» один раз с помощью функции printf() и один раз с помощью потока cout (всего 4 сообщения).

#include <iostream>
#include <clocale>

int main()
{
    setlocale(LC_ALL, "russian");
    printf("Hello World!\n");
    std::cout << "Привет Мир!";
    printf("Rise and shine!\n");
    std::cout << "Проснись и пой!";
    return 0;
}


