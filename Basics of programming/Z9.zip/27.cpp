﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 27 (Z9)
/* Написать функцию void sort(float arr[], int len, float x), которая сортирует массив arr длины len по возрастанию модуля разности между
числом x и элементом массива. После сортировки в функции main() сформировать массив dist[] из модулей разности (dist[i] = |arr[i] - x|) и
вывести его. Несравнимые элементы (с равными модулями разности) по отношению друг к другу располагаются произвольно.*/

#include <iostream>
#include <clocale>
#include <math.h>
using namespace std;

float* read_array(int len) {
    float* arr = new float[len];
    for (int i = 0; i < len; i++) cin >> arr[i];
    return arr;
}

void print_array(float arr[], int len) {
    for (int i = 0; i < len; i++) cout << arr[i] << " "; 
    cout << endl;
}

void sort(float arr[], int len, float x) {
    for (int i = 0; i < len; i++) {
        arr[i] = x - arr[i];
        arr[i] = abs(arr[i]);
    }
    float t;
        for (int i = 0; i < len; i++)
            for (int j = 0; j < (len - 1); j++)
                if (arr[j] > arr[j + 1]) {
                    t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                }
}

int main() {
    setlocale(LC_ALL, "russian");
    float x;
    int len;
    float* arr;
    cout << "Введите размер массива:";
    cin >> len;
    cout << "Введите массив:";
    arr = read_array(len);
    cout << "Введите число x:";
    cin >> x;
    sort(arr, len, x);
    print_array(arr, len);
    delete[]arr;
    return 0;
}