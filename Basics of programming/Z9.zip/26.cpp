﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 26 (Z9)
/*  Написать функцию void sort(int arr[], int len, bool even_greater), которая сортирует массив arr длины len по возрастанию по следующим
правилам сравнения чисел: 1) если even_greater = true, то любое чётное число больше любого нечётного, иначе — меньше; 2) чётные с чётными
и нечётные с нечётными сравниваются как обычно.*/

#include <iostream>
#include <clocale>
using namespace std;

int* read_array(int len) {
    int* arr = new int[len];
    for (int i = 0; i < len; i++) cin >> arr[i];
    return arr;
}

void print_array(int arr[], int len) {
    for (int i = 0; i < len; i++) cout << arr[i] << " ";
    cout << endl;
}

void sort(int arr[], int len, int ij = 0) {
    int i = ij, j = ij, t;
    for (i; i < len; i++)
        for (j; j < len - 1; j++)
            if (arr[j] > arr[j + 1]) {
                t = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = t;
            }
}

void sort_greater(int arr[], int len, bool even_greater) {
    int t, ilen=0;
    if (even_greater == true) {
        for (int i = 0; i < len; i++)
            for (int j = 0; j < len - 1; j++)
                if (arr[j] % 2 == 0) {
                    t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                }
        for (int i = 0; i < len; i++)
            if (arr[i] % 2 == 0) {
                ilen = i;
                break;
            }
        sort(arr, ilen);
        sort(arr, len, ilen);
    }
    if (even_greater == false) {
        for (int i = 0; i < len; i++)
            for (int j = 0; j < len - 1; j++)
                if (arr[j] % 2 == 1) {
                    t = arr[j];
                    arr[j] = arr[j + 1];
                    arr[j + 1] = t;
                }
        for (int i = 0; i < len; i++)
            if (arr[i] % 2 == 1) {
                ilen = i;
                break;
            }
        sort(arr, ilen);
        sort(arr, len, ilen);
    }
}

int main() {
    setlocale(LC_ALL, "russian");
    int len;
    int* arr;
    cout << "Введите размер массива:";
    cin >> len;
    cout << "Введите массив :";
    arr = read_array(len);
    bool asc;
    cout << "Как отсортировать массив?(1 - нечет-чет,0 - чет-нечет):";
    cin >> asc;
    sort_greater(arr, len, asc);
    print_array(arr, len);
    delete[]arr;
    return 0;
}