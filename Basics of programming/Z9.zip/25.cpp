﻿//Базаров Алмазбек Султанбаевич
//КИ20-07б(1 подгруппа)
//задание 25 (Z9)
/*  Написать функцию void sort(float arr[], int len, bool asc), которая сортирует массив arr длины len по возрастанию,
если asc = true, и по убыванию, если asc = false.*/

#include <iostream>
#include <clocale>
using namespace std;

float* read_array(int len) {
    float* arr = new float[len];
    for (int i = 0; i < len; i++) cin >> arr[i];
    return arr;
}

void print_array(float arr[], int len) {
    for (int i = 0; i < len; i++) cout << arr[i] << " ";
    cout << endl;
}

void sort(float arr[], int len, bool asc) {
    float t;
    if (asc == true)
    for (int i = 0; i < len; i++)
        for (int j = 0; j < (len - 1); j++)
            if (arr[j] > arr[j + 1]) {
                t = arr[j];
                arr[j] = arr[j + 1];
                arr[j + 1] = t;
            }
    if (asc == false)
         for (int i = 0; i < len; i++)
             for (int j = 0; j < (len - 1); j++)
                 if (arr[j] < arr[j + 1]) {
                     t = arr[j];
                     arr[j] = arr[j + 1];
                     arr[j + 1] = t;
                 }
}

int main() {
    setlocale(LC_ALL, "russian");
    int len;
    float* arr;
    cout << "Введите размер массива:";
    cin >> len;
    cout << "Введите массив:";
    arr = read_array(len);
    bool asc;
    cout << "Как отсортировать массив?(1 - по возрастанию,0 - по убыванию):";
    cin >> asc;
    sort(arr, len, asc);
    print_array(arr, len);
    delete[]arr;
    return 0;
}